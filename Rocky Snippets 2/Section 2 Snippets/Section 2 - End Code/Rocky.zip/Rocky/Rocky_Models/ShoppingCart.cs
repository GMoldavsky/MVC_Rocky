﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Rocky_Models
{
    public class ShoppingCart
    {
        public int ProductId { get; set; }
    }
}
